# Raspberry Pi Internet Thing Videos
Example code to go along with video series on building an internet 'thing' with a Raspberry Pi.  Demonstrates building a web app in Python that controls the Pi hardware with a web interface.

## Video List
* [Raspberry Pi & Python Internet 'Thing' pt. 1 with Tony D!](https://www.youtube.com/watch?v=L55QYFnnrgo)
* [Raspberry Pi & Python Internet 'Thing' pt. 2 with Tony D!](https://www.youtube.com/watch?v=s1omSb9iwKE)
* [Raspberry Pi & Python Internet 'Thing' pt. 3 with Tony D!](https://www.youtube.com/watch?v=oeGI5OMAheg)
* [Raspberry Pi & Python Internet 'Thing' pt. 4 with Tony D!](https://www.youtube.com/watch?v=cAymVFeoz3s)
